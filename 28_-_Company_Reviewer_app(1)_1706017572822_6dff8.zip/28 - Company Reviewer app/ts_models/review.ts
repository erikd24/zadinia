export class Review {
    constructor(public whoWroteThis: string, public numberOfPointsOutOfFive: number, public goodPoints: string[], public badPoints: string[]) {

    }
}