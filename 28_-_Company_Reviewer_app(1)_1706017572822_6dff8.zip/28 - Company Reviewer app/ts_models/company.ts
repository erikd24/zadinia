import { Review } from "./review";

export class Company  {
    constructor(public id: number, public companyName: string, public companyInfo: string, public reviews: Review[]) {
        
    }
}