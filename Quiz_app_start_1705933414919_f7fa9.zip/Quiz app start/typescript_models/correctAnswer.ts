export interface CorrectAnswer {
    question: number;
    answer: number;
}