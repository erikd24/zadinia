export interface Answer {
    text: string;
    isCorrect: boolean;
}