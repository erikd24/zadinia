import { Test } from "../typescript_models/test";

const apiUrl: string = 'http://localhost:3000/tests'; // Zmeňte URL na adresu vášho JSON Serveru

export async function addTest(test: Test): Promise<void> {
    await fetch(apiUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(test),
    });
}

export async function getAllTests(): Promise<Test[]> {
    const response: Response = await fetch(apiUrl);
    if (response.ok) {
        const tests: Test[] = await response.json();
        return tests;
    } else {
        return [];
    }
}

export async function getTestById(id: number): Promise<Test | null> {
    const response: Response = await fetch(`${apiUrl}/${id}`);
    if (response.ok) {
        const test: Test = await response.json();
        return test;
    } else {
        return null;
    }
}

export async function updateTest(id: number, updatedTest: Test): Promise<void> {
    await fetch(`${apiUrl}/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(updatedTest),
    });
}

export async function deleteTest(id: number): Promise<void> {
    await fetch(`${apiUrl}/${id}`, {
        method: 'DELETE',
    });
}